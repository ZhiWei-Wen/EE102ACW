If your version of MATLAB does not include the functions fft.m and fftshift.m,
then use CTFT_approx_no_fft.m. Otherwise, use the default version CTFT_approx.m,
which is far more efficient, as it uses a Fast Fourier Transform algorithm.


